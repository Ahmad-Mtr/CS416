#!/bin/bash

rm section1_data.txt
rm section2_data.txt
rm section3_data.txt
rm section4_data.txt
rm final_report.txt

echo 'deleted successfully'